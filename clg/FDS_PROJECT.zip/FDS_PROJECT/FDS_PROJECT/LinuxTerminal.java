


public class LinuxTerminal {
    public static void main(String[] args) {
        new terminal();
        terminal.command();  // init commands in an array list
    }
}

