package test;

public class CurrDirectory {

    public static void main(String[] args) {

        String path = System.getProperty("user.dir");
        System.out.println("Working Directory = " + path);

    }
}